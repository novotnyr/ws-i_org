Introduction to logical package (Scenarios, Monitor and Analyzer):

These WS-I materials are divided in two parts: 
1. Interoperability Testing Suite: Scenarios and test reports 
2. Testing Tools for Monitoring and Test Analysis: Message capture functionality and test analysis

The two packages focus on providing:
5.	Evidence of interoperability between web services instances and artifacts.
6.	An indication of conformance to the Profile of web service instances and artifacts analyzed.  
 
Interoperability Testing Suite

The test scenarios package is focused on interoperability and provides a basis for the message exchanges that can serve as 
inputs into the test analysis and reporting phases (as outlined in the Test Tools and Process document). 
 
The set of test scenarios defined - or a subset - is the basis for assessing Interoperability between web services 
instances, as required for validating and publishing this profile. The set or subset of scenarios to be exercised 
during interoperability testing will depend on the Profile area that a web service instance supports.  Interoperability 
will be evaluated by observing web services instance interacting using the test scenarios. 

In addition to evidencing interoperability, the artifacts in this package, when processed in a test environment, will 
produce input for the testing tools. 

Testing Tools for Monitoring and Test Analysis
 
The Test Tools package provides the test artifacts used to monitor and capture, and then analyze message exchanges.  
The message captures and other artifacts can be assessed for conformance to the Profile by these test tools.

In the Monitor package, the monitor capability captures and transforms message exchanges into a pre-determined format. 

In the Analyzer package, the test analyzer generates reports, for example, from the message exchanges. Other methods may 
be used to generate the appropriate exchanges.  Using the analyzer, test reports show the test assertions exercised and 
the results can also provide an indication of conformance to a profile as defined in the test overview.  
