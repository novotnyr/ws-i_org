Readme for SAWG BSP 1.1 architecture - Scenario Testing

These materials - methods, process, and documents or packages - are used in testing with the primary focus of promoting interoperability.  For example, the test scenarios are focused on interoperability and provide a basis for the message exchanges that serve as inputs into the test analysis and reporting phases outlined in the test materials. 
 
The test scenarios are the basis for assessing Interoperability between web services instances, as required for validating and publishing this profile. The test scenarios to be exercised during interoperability testing will depend on the Profile area that a web service instance supports.   Message exchanges show how web services instances interact when exercising the test scenarios.

Reports are generated using analyzer methods that exercise the test assertions. The results can also provide an indication of conformance to a profile as defined in the test materials.  

In addition to interoperability testing, this test material may be used for assessing conformance to the Profile of web service instances and artifacts analyzed. The analyzer (http://www.ws-i.org/deliverables/workinggroup.aspx?wg=testingtools) can be used for this assessment. The results provided, however, provide only an indication of conformance due to limits in test methods or scope for example.

The package provided includes:
1.	Test methodology: Included in BSP 1.1 Sample Architecture document
2.	XML and WSDL samples: Included both in BSP 1.1 Sample Architecture document and as individual files are provided in a compressed file for ease of use: see BSP11_ScenarioPackage
3.	Test scenario definitions: Included in BSP 1.1 Sample Architecture document
4.	Test methods: Test method package and Test Assertion Document (TAD).[1]

The definition on how to use the methods described have already been published by WS-I � see Deliverables, www.ws-i.org.

[1] Included with test tools package.