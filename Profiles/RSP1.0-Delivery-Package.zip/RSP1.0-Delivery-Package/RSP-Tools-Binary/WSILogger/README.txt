INSTALLATION -

1) Download and install the latest version of Apache HTTP Server
	http://httpd.apache.org/download.cgi
	Version 2.0 or higher

2) Download and Install Python 2.5
	http://python.org/download/releases/2.5.4/
	NOTE - During installation for Windows, it asked to install for a particular user or all users.  I had to choose all users for it to work properly. 

3) Download and Install mod_python v3.3.1 ( an Apache module which enables Python support )
	http://httpd.apache.org/modules/python-download.cgi
        Your Apache configuration file should now have a line similar to this:
		LoadModule python_module C:/Apache2.2/modules/mod_python.so

4) Download and Install ActivePerl 5.10.X
	http://www.activestate.com/activeperl/downloads/

5) Use perl ppm to download and install mod_perl
	From command line execute the following:
		C:\> ppm install http://cpan.uwinnipeg.ca/PPMPackages/10xx/mod_perl.ppd
	Documentation help here:
	http://perl.apache.org/docs/2.0/os/win32/install.html#PPM_Packages

6) Use perl ppm to download and install XML-LibXML
	ppm install http://cpan.uwinnipeg.ca/PPMPackages/10xx/XML-LibXML-Common.ppd
	ppm install http://cpan.uwinnipeg.ca/PPMPackages/10xx/XML-LibXML.ppd

6) Enable the perl module in Apache by adding the following line to httpd.conf
	LoadFile "C:/Perl/bin/perl510.dll"
	LoadModule perl_module modules/mod_perl.so

6) Copy files from this zip into Apache -
        - The wsi folder into <Apache_Home>/htdocs
        - Follow the directions in httpd.conf.txt to modify the Apache configuration



BASIC OPERATION -

1) Start Apache HTTP Server
	In Windows, Start -> Apache HTTP Server 2.2 -> Control Apache Server -> Start Apache in Console

2) Configure your web service client to use a proxy.
	Example - proxy server = localhost, proxy port = 8080

3) Use a browser to view the monitor user interface.
   Open the url http://localhost:8080/wsi/monitor.psp

4) Run your web service tests.

5) Click the 'Refresh' button on the monitor page to view messages received.

6) Click the 'Create Log File' button to create a WSI Log.

7) You can view the log in the browser.
   Logs are stored in <Apache_Home>/htdocs/wsi/logs

8) After a log is created, use the DescriptionFileImporter tool included in this package to import the WSDL and XSD files for the web service into that log file.  This is necessary before running the Analayzer.



HELP -

1) Messages are not making it through the proxy to the server.
	- Verify that you do not have a firewall enabled and blocking the proxy port.
	- Verify that the client IP address or hostname is allowed in the Proxy 'Allow' in httpd.conf



DROPPING MESSAGES -

1) Use a browser to view the monitor user interface.
   Open the url http://localhost:8080/wsi/admin.psp

2) Using the radio buttons, select a method for setting the wsa:Action.

3) Set the wsa:Action to use.

4) Press the "Apply" button to save the configuration.

5) After the first message with the specified wsa:Action is dropped,
	the configuration will reset to not drop any messages.



SCHEMA VALIDATION -
Temporary tool to perform schema validation for the log.  Ultimately this step should take place when the log is generated.
This tool will add the schemaValid attribute to both messageContents and descriptionFile elements.
Also, it will add the encoding attribute to descriptionFile elements.

1) Run the perl script wsi/validateLog.pl against a log.

2) USAGE:  wsi/validateLog.pl <logFileLocation> <newLogFileLocation>
