USAGE:

import <Input Log File Name> <Output Log File Name> <Service WSDL File Name>

Please look at importSample.bat to see an example.
Parameters can be relative or full paths.

The WSDL file location can also be a URL such as http://localhost:9080/soap12/service/BaseDataTypesDocLitWService/WEB-INF/wsdl/BaseDataTypesDocLitW.wsdl


Java is required.  Only Java 5 has been tested.