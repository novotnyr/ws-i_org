  #file:wsi/ResponseFilter.pm
  #-------------------------------------
  package wsi::ResponseFilter;
  
  use strict;
  use warnings;
  
  use base qw(Apache2::Filter);
  
  use Apache2::Const -compile => qw(OK DECLINED);

  use Apache2::RequestRec ();
  use APR::Table ();
  use APR::UUID ();
  
  use constant BUFF_LEN => 65536;
  use constant LOG_DIR => "htdocs/wsi/temp";
  
  sub handler : FilterRequestHandler {
      my $f = shift;
      my $r = $f->r;

      #my $uri = $r->uri();
      # If the uri starts with /wsi, do not log it
      #if ($uri =~ /^\/wsi/) {
      #    return Apache2::Const::DECLINED;
      #}

      my $method = $r->method();
      # Only log if the method is POST
      unless ($method =~ "POST") {
          return Apache2::Const::DECLINED;
      }

      my $notes = $r->notes();
      my $convkey = "conversation";
      my $reskey = "response";

      my $conversation;
      my $response;

      if ($notes->EXISTS($convkey)) {
          $conversation = $notes->get($convkey);
      } else {
          $conversation = APR::UUID->new->format;
          $notes->set($convkey, $conversation);
      }

      if ($notes->EXISTS($reskey)) {
          $response = $notes->get($reskey);
      } else {
          $response = APR::UUID->new->format;
          $notes->set($reskey, $response);

          # Store the http headers and status line in a log
          my $statusline = $r->status_line();
          my $headers = $r->headers_out();
          open(my $headerlog, '>>', LOG_DIR . '/headers_' . $response . '.log');
          print $headerlog "REQUEST-LINE: $statusline\n";
          foreach my $key (keys %{$headers}) {
              print $headerlog "$key: $headers->{$key}\n";
          }
          close($headerlog);

          open(my $historylog, '>>', LOG_DIR . '/history.log');
          print $historylog "$convkey:$conversation $reskey:$response\n";
          close($historylog);
      }
      
      open(my $log, '>>', LOG_DIR . '/message_' . $response . '.log');
  
      while ($f->read(my $buffer, BUFF_LEN)) {
          $f->print($buffer);
          print $log $buffer;
      }

      close($log);
  
      Apache2::Const::OK;
  }
  1;
