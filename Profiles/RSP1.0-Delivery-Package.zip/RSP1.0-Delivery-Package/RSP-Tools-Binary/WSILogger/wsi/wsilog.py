from mod_python import apache
import tempfile, os, uuid
import multifile, mimetools
from xml.etree import ElementTree as ET

ENCODING = None

class Conversation:
    def __init__(self, cid):
        self.id = cid
        self.request = None
        self.response = None

def setDropMessageAction(wsaAction):
    file = open('htdocs/wsi/wsi.conf', 'w')
    file.write('wsiLogDropAction=' + wsaAction)
    file.close()

def getDropMessageAction():

    s = None
    if os.path.isfile('htdocs/wsi/wsi.conf'):
        file = open('htdocs/wsi/wsi.conf', 'r')
        s = file.read()
        file.close()

    if s != None:
        parts = s.split('=')
        if len(parts) == 2:
            wsaAction = parts[1]
            return wsaAction
    return None

def getHistoryFileName():

    return 'htdocs/wsi/temp/history.log'

def loadHistory():

    history = dict()
    historyFileName = getHistoryFileName()
    if os.path.isfile(historyFileName):
        file = open(historyFileName, 'r')

        s = file.readline()
        while s:
            tokens = s.strip('\n').split(' ')
            cid = tokens[0].split(':')[1]
            conversation = history.get(cid)
            if conversation is None:
                conversation = Conversation(cid)
            tokens = tokens[1].split(':')
            if tokens[0] == "request":
                conversation.request = tokens[1]
            elif tokens[0] == "response":
                conversation.response = tokens[1]
            history.setdefault(cid, conversation)
            
            s = file.readline()

        file.close();

    return history

def loadHeaders(id):

    file = open( getFileName(id, 'headers'), 'r')
    
    headerTxt = ''
    s = file.read()
    while s:
        headerTxt = headerTxt + s
        s = file.read()

    headerLines = headerTxt.splitlines()
    headerDict = dict()
    for header in headerLines:
        index = header.find(':')
        key = header[:index]
        value = header[index+1:].strip()
        headerDict.setdefault(key, value)

    headers = HttpHeaders(headerDict)

    return headers

def getConversation(notes):

    conversation = 'conversation'
    if conversation not in notes:
        value = str(uuid.uuid4())
        notes.add(conversation, value)
    else:
        value = notes[conversation]

    return value

def generateLog():

    history = loadHistory()
    log = getLog()
    for conversation in history.itervalues():
        if conversation.request != None:
            logMessage(log, conversation.request, 'request', conversation.id)
        if conversation.response != None:
            logMessage(log, conversation.response, 'response', conversation.id)
    logFileName = saveLog(log)
    os.remove(getHistoryFileName())

    return logFileName

def logMessage(log, id, type, conversation):

    try:
        headers = loadHeaders(id)
#  Look at the content type to determine to log it as an mtom or soap message
        if headers.contentType != None and headers.contentType.value == "multipart/related":
            logMtomMessage(log, id, type, conversation, headers)
            os.remove( getFileName(id) )
            os.remove( getFileName(id, 'headers') )
# Cannot check for application/soap+xml or text/xml as there can be 
# empty response messages with no content type
        else:
            logSoapMessage(log, id, type, conversation, headers)
            os.remove( getFileName(id) )
            os.remove( getFileName(id, 'headers') )
    except Exception, e:
        apache.log_error(str(e))

def logSoapMessage(log, id, type, conversation, httpHeaders):

    message = createLogMessage(log, id, type, conversation, httpHeaders)
    if httpHeaders.contentType is None:
        encoding = None
    else:
        encoding = httpHeaders.contentType.getParameter('charset')
    messageContents = createLogMessageContents(log, id, encoding)
    message.append(messageContents)

def logMtomMessage(log, id, type, conversation, httpHeaders):

    boundary = httpHeaders.contentType.getParameter('boundary')

    message = createLogMessage(log, id, type, conversation, httpHeaders)

    f = open(getFileName(id), 'r')

    file = multifile.MultiFile(f)
    file.push(boundary)

    while file.next():
        submsg = mimetools.Message(file)
        headers = dict() 
        for header in submsg.headers:
            index = header.find(':')
            key = header[:index]
            value = header[index+1:].strip()
            headers.setdefault(key, value)
        mimeHeaders = HttpHeaders(headers)

        messageAttachments = createLogMessageAttachments(log, boundary, mimeHeaders)
        message.append(messageAttachments)

        submsg.rewindbody()

#        temp = open('htdocs/wsi/logs/mime_' + id + '.log', 'w+')
        temp = tempfile.TemporaryFile('w+')

        s = file.read()
        while s:
            temp.write(s)
            s = file.read()

        # HACK to remove an illegal character when the encoding is UTF-16LE
        if mimeHeaders.contentType.value == "application/xop+xml":
            encoding = mimeHeaders.contentType.getParameter('charset')
            if encoding.upper() == "UTF-16LE":
                temp.seek(-3, os.SEEK_CUR)
                temp.truncate()


        temp.seek(0)
        if mimeHeaders.contentType.value == "application/xop+xml":
            encoding = mimeHeaders.contentType.getParameter('charset')
            mimeSoapContent = createLogMimeSoapContent(log, temp, encoding)
            messageAttachments.append(mimeSoapContent)
        else:
            mimeContent = createLogMimeContent(log, temp)
            messageAttachments.append(mimeContent)
        temp.close()

    file.pop()
    f.close()

def getFileName(id, type='message'):

    return 'htdocs/wsi/temp/' + type + '_' + id + '.log'

def parseFile(file):

    try:
        doc = ET.parse(file)
    except Exception, e:
        apache.log_error(str(e))
        file.seek(0)
        doc = parseFileWithProlog(file)

    if doc is None:
        return None
    else:
        return doc.getroot()

def parseFileWithProlog(file):

    temp = tempfile.TemporaryFile('w+')
    temp.write('<?xml version="1.0" ?>')

    s = file.read()
    while s:
        temp.write(s)
        s = file.read()

    temp.seek(0)
    try:
        doc = ET.parse(temp)
    except Exception:
        doc = None
    finally:
        temp.close()

    return doc

def getLogUri():

    return "http://www.ws-i.org/testing/2008/02/log/"

def getLog():

    log = ET.parse('htdocs/wsi/wsilog.template.xml')
    messages = ET.Element( ET.QName(getLogUri(), "messageLog") )
    log.getroot().append(messages)

    return log

def saveLog(log):

    logId = str(uuid.uuid4())
    logFileName = 'WSI_' + logId + '.xml'

    file = open('htdocs/wsi/logs/' + logFileName, 'w')

    encoding = globals()["ENCODING"]
    if encoding is None:
        encoding = 'utf-8'

    # Always save the log using utf-8
    log.write(file, 'utf-8')
    file.close()

    return logFileName

def createLogMessage(log, id, type, conversation, httpHeaders):

    messages = log.getroot().find("{" + getLogUri() + "}messageLog")
    message = ET.Element( ET.QName(getLogUri(), "message") )
    messages.append(message)
    message.set('id', id)
    message.set('conversation', conversation)
    message.set('type', type)
    message.append( createLogHttpHeaders(log, httpHeaders) )

    return message

def createLogMessageContents(log, id, headerEncoding):

    messageContents = ET.Element( ET.QName(getLogUri(), "messageContents") )
    messageContents.set('xmlVersion', '1.0')
    messageContents.set('containsProcessingInstructions', 'false')
    messageContents.set('containsDTD', 'false')
    if headerEncoding != None:
        messageContents.set('encoding', headerEncoding)
        globals()["ENCODING"] = headerEncoding
    else:
        messageContents.set('encoding', 'utf-8')

    file = open(getFileName(id), 'r')
    soapMessage = parseFile(file)
    file.close()

    if soapMessage != None:
        messageContents.append(soapMessage)
        messageContents.set('validXml', 'true')
        # TODO - Actually validate the messages
        messageContents.set('schemaValid', 'true')
    else:
        messageContents.set('validXml', 'false')
        messageContents.set('schemaValid', 'false')

    return messageContents

def createLogMessageAttachments(log, boundary, mimeHeaders):

    messageAttachments = ET.Element( ET.QName(getLogUri(), "messageAttachments") )
    messageAttachments.set('boundaryString', boundary)
    messageAttachments.append( createLogMimeHeaders(log, mimeHeaders) )

    return messageAttachments

def createLogMimeSoapContent(log, file, headerEncoding):

    messageContents = ET.Element( ET.QName(getLogUri(), "mimeSoapContent") )
    messageContents.set('xmlVersion', '1.0')
    messageContents.set('containsProcessingInstructions', 'false')
    messageContents.set('containsDTD', 'false')
    if headerEncoding != None:
        messageContents.set('encoding', headerEncoding)
        globals()["ENCODING"] = headerEncoding
    else:
        messageContents.set('encoding', 'utf-8')

    soapMessage = parseFile(file)
    if soapMessage != None:
        messageContents.append(soapMessage)
        messageContents.set('validXml', 'true')
    else:
        messageContents.set('validXml', 'false')

    return messageContents

def createLogMimeContent(log, file):

    mimeContent = ET.Element( ET.QName(getLogUri(), "mimeContent") )

    s = file.read()
    data = ''
    while s:
        data = data + s
        s = file.read()

    mimeContent.text = data

    return mimeContent

def createLogHttpHeaders(log, hheaders):

    httpHeaders = ET.Element( ET.QName(getLogUri(), "httpHeaders") )

    if hheaders.requestLine != None:
        reqLine = ET.Element( ET.QName(getLogUri(), "requestLine") )
        reqLine.text = hheaders.requestLine
        httpHeaders.append(reqLine)        

    if hheaders.contentType != None:
        httpHeaders.append( createLogContentTypeHeader(log, hheaders.contentType) )
    for header in hheaders.headers:
        httpHeaders.append( createLogHttpHeader(log, 'httpHeader', header) )

    return httpHeaders

def createLogMimeHeaders(log, mheaders):

    mimeHeaders = ET.Element( ET.QName(getLogUri(), "mimeHeaders") )
    mimeHeaders.append( createLogContentTypeHeader(log, mheaders.contentType) )
    for header in mheaders.headers:
        mimeHeaders.append( createLogHttpHeader(log, 'mimeHeader', header) )

    return mimeHeaders

def createLogContentTypeHeader(log, contentType):

    contentTypeHeader = ET.Element( ET.QName(getLogUri(), "contentTypeHeader") )
    contentTypeHeader.set('type', contentType.type)
    contentTypeHeader.set('subtype', contentType.subtype)
    for param in contentType.parameters:
        contentTypeHeader.append( createLogHeaderParameter(log, param) )

    return contentTypeHeader

def createLogHttpHeader(log, name, header):

    httpHeader = ET.Element( ET.QName(getLogUri(), name) )
    httpHeader.set('key', header.key)
    httpHeader.set('value', header.value)
    httpHeader.set('quoted', header.quoted)
    for param in header.parameters:
        httpHeader.append( createLogHeaderParameter(log, param) )

    return httpHeader

def createLogHeaderParameter(log, param):

    parameter = ET.Element( ET.QName(getLogUri(), "parameter") )
    parameter.set('key', param.key)
    parameter.set('value', param.value)
    parameter.set('quoted', param.quoted)    

    return parameter

def debugString(name, value):

    f = open('logs/'+name+'.log', 'a')
    f.write(name+'['+value+']')
    f.close()

class HttpHeaders:
    contentType = None
    requestLine = None
    headers = []
    def __init__(self, headerDict):
        self.headers = []
        for k, v in headerDict.iteritems():
            if k == 'REQUEST-LINE':
                self.requestLine = v
            elif k.upper() == 'CONTENT-TYPE':
                self.contentType = ContentType(v)
            else:
                header = HttpHeader(k, v)
                self.headers.append(header)

class ContentType:
    def __init__(self, v):
        self.parameters = []
        index = v.find(';')
        if index == -1:
            self.value = v.strip()
        else:
            tokens = v.split(';')
            self.value = tokens[0].strip()
            params = tokens[1:]
            for param in params:
                p = HeaderParameter(param)
                self.parameters.append(p)

        parts = self.value.split('/')
    
        if len(parts) == 2:
            self.type = parts[0]
            self.subtype = parts[1]
        else:
            self.type = self.value
            self.subtype = self.value

    def getParameter(self, k):
        for param in self.parameters:
            if param.key.upper() == k.upper():
                return param.value

class HttpHeader:
    def __init__(self, k, v):
        self.key = k
        self.parameters = []
        index = v.find(';')
        if index == -1:
            self.value = v.strip()
        else:
            tokens = v.split(';')
            self.value = tokens[0].strip()
            params = tokens[1:]
            for param in params:
                p = HeaderParameter(param)
                self.parameters.append(p)

        if self.value.find('"') == -1:
            self.quoted = 'false'
        else:
            self.value = self.value.strip('"')
            self.quoted = 'true'

class HeaderParameter:
    def __init__(self, param):
        param = param.strip()
        #parts = param.split('=')
        index = param.find('=')
        #if len(parts) == 2:
        if index != -1:
            #self.key = parts[0]
            self.key = param[:index]
            #value = parts[1]
            value = param[index+1:]
            if value.find('"') == -1:
                self.value = value
                self.quoted = 'false'
            else:
                self.value = value.strip('"')
                self.quoted = 'true'
        else:
            apache.log_error('ERROR: No = found in HttpHeader parameter ' + param)
            self.key = param
            self.value = param
            self.quoted = 'false'  
