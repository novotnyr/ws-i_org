  #file:wsi/RequestFilter.pm
  #-------------------------------------
  package wsi::RequestFilter;
  
  use strict;
  use warnings;
  
  use base qw(Apache2::Filter);
  
  use Apache2::Const -compile => qw(OK DECLINED HTTP_OK DONE);

  use Apache2::RequestRec ();
  use Apache2::Log;
  use APR::Table ();
  use APR::UUID ();
  use XML::LibXML;
  
  use constant BUFF_LEN => 65536;
  use constant LOG_DIR => "htdocs/wsi/temp";
  
  sub handler : FilterRequestHandler {
      my $f = shift;
      my $r = $f->r;

      my $wsiConfFile = 'htdocs/wsi/wsi.conf';
      my $wsaAction;
      # Does the WSI Conf file exist?
      if (-e $wsiConfFile) {
          open(my $conf, '<', $wsiConfFile);
          my $s = <$conf>;
          close($conf);

          # Split the line into parts using = as the delim
          my @parts = split(/=/, $s);
          if ($#parts == 1) {
              $wsaAction = $parts[1];
          }
      }

      my $method = $r->method();
      # Only log if the method is POST
      unless ($method =~ "POST") {
          return Apache2::Const::DECLINED;
      }

      my $notes = $r->notes();
      my $convkey = "conversation";
      my $reqkey = "request";

      my $conversation;
      my $request;

      if ($notes->EXISTS($convkey)) {
          $conversation = $notes->get($convkey);
          $request = $notes->get($reqkey);
      } else {
          $conversation = APR::UUID->new->format;
          $notes->set($convkey, $conversation);
          $request = APR::UUID->new->format;
          $notes->set($reqkey, $request);
      }

      my $requestLogName = LOG_DIR . '/message_' . $request . '.log';

      # Store the request data in a log
      open(my $log, '>>', $requestLogName);
      while ($f->read(my $buffer, BUFF_LEN)) {
          print $log $buffer;
      }
      close($log);

      # Do following only after we have seen the end of stream
      if ($f->seen_eos) {

          if ($wsaAction) {
              $r->log_error('WSI conf drop wsa:ACTION = [' . $wsaAction . ']');

              my $parser = XML::LibXML->new();
              my $doc    = $parser->parse_file($requestLogName);

              my $xpc = XML::LibXML::XPathContext->new($doc);
              $xpc->registerNs(wsa => 'http://www.w3.org/2005/08/addressing');

              foreach my $node ($xpc->findnodes('//wsa:Action')) {
                  if($node->to_literal eq $wsaAction) {
                      $r->log_error('Dropped message with wsa:Action ' . $wsaAction);
                      $r->status(Apache2::Const::HTTP_OK);
                      $r->proxyreq(0);
                      unlink $requestLogName;
                      unlink $wsiConfFile;
                      return Apache2::Const::DONE;
                  }
              }
          } 

          # Give the request data to the next filter in the chain
          open(my $log, '<', $requestLogName);
          my $buffer;
          while (read($log, $buffer, BUFF_LEN)) {
              $f->print($buffer);
          }
          close($log);

          # Store the http headers and request line in a log
          my $requestline = $r->the_request();
          my $headers = $r->headers_in();
          open(my $headerlog, '>>', LOG_DIR . '/headers_' . $request . '.log');
          print $headerlog "REQUEST-LINE: $requestline\n";
          foreach my $key (keys %{$headers}) {
              print $headerlog "$key: $headers->{$key}\n";
          }
          close($headerlog);

          # Store the request and conversation ids in the history log
          open(my $historylog, '>>', LOG_DIR . '/history.log');
          print $historylog "$convkey:$conversation $reqkey:$request\n";
          close($historylog);
      }

      
      #open(my $log, '>>', LOG_DIR . '/message_' . $request . '.log');
  
      #while ($f->read(my $buffer, BUFF_LEN)) {
      #    $f->print($buffer);
      #    print $log $buffer;
      #}

      #close($log);
  
      Apache2::Const::OK;
  }

  1;
