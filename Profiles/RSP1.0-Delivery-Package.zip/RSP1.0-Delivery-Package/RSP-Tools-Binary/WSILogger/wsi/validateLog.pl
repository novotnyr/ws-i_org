use XML::LibXML;

sub validate{
    my $parser = XML::LibXML->new;
    my $log    = $parser->parse_file($_[0]);

    validateMessageContents($log);
    validateDescriptionFiles($log);

    my $newLog;
    if ($#_ == 1) {
        $newLog = $_[1];
    } else {
        $newLog = $_[0] . 'validated.xml';
    }
    $log->toFile($newLog);
}

sub validateMessageContents{
    my $log = $_[0];

    my $xpc = XML::LibXML::XPathContext->new($log);
    $xpc->registerNs(wsil => 'http://www.ws-i.org/testing/2008/02/log/');

    my $soapSchema = XML::LibXML::Schema->new(location => 'http://www.w3.org/2003/05/soap-envelope/');

    foreach my $node ($xpc->findnodes('//wsil:messageContents')) {

        # Message validation needs to be implemented
        $node->setAttribute('schemaValid', 'true');
    }
}

sub validateDescriptionFiles{
    my $log = $_[0];

    my $xpc = XML::LibXML::XPathContext->new($log);
    $xpc->registerNs(wsil => 'http://www.ws-i.org/testing/2008/02/log/');

    #my $wsdlSchema = XML::LibXML::Schema->new(location => 'http://schemas.xmlsoap.org/wsdl/');

    foreach my $node ($xpc->findnodes('//wsil:descriptionFile')) {
        
        # Wsdl validation needs to be implemented
        $node->setAttribute('schemaValid', 'true');

        # Temporary Fix to Add encoding - Remove this later
        if (! $node->hasAttribute('encoding') ) {
            $node->setAttribute('encoding', 'utf-8');
        }
    }
}


if ($#ARGV == 0) {
    validate($ARGV[0]);
}
elsif ($#ARGV == 1) {
    validate($ARGV[0], $ARGV[1]);
} else {
    print 'USAGE:  validateLog <InputLogName> <OutputLogName>';
}