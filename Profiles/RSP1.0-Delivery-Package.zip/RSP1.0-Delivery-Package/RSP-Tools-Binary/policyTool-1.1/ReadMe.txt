HOW TO USE THIS TOOL
--------------------

  1.) (optionally) build the tool - follow the instructions in
                                    BuildInstructions.txt

  2.) java -jar policytool.jar -help

  3.) java -jar policytool.jar process -help

  Command:
  --------
  process - This command can be used to determine if an endpoint
            supports or requires a particular policy assertion. The
            result will be one value, for each assertion from
            ('noassertion','undetermined','supported','required'). It
            updates WS-I message log file for each policy assertion
            when the assertion is not specified. When the specific
            assertion is given, then it updates the log file only for
            that assertion. It creates/updates element wsil:feature
            for each assertion to be determined. The value of the name
            attribute of this element will be of the form
            namespace/localpart of the corresponding assertion and the
            value of the mode attribute will the determined value.
  
  
  Mandatory argument(s):
  ----------------------
  wsdl - The url of the wsdl document.

         Shortcut: w


  Optional arguments(s):
  ----------------------
  logFile - The path to the WS-I log file to be updated. If the file
            does not exist, the file will be created and updated with
            all the wsil:feature information. The default file name
            is:logFile.xml

            Shortcut: lf

  serviceQName - The QName of the service. By default the tool will
                 process all the services. The value is of the form
                 {ServiceNS}serviceName

                 Shortcut: sqn

  portName - The name of the port to be tested. By default, the tool
		     will process all the ports in the specified service.

             Shortcut: pn

  assertionQName - The QName of the policy assertion to be determined
                   if supported or required. The QName must be of the
                   form {namepace}localpart. If this is not specified,
                   all the assertion in the effective policy will be
                   used and for each assertion, the determination of
                   if that is required or supported is done.
  
                   Shortcut: aqn

  assertRecursive - The flag (true/false) to indicate if all the
                    sub-assertions need to be procesed
                    recursively. The default value is false. When
                    true, the system will create a set of policy
                    alternatives and within each alternative it will
                    further process for each assertion if that is
                    required/supported.

                    Shortcut: ar

  policyURI      - The policy namespace uri. The default value is: http://
                   www.w3.org/ns/ws-policy. The value could be one from (http://
                   schemas.xmlsoap.org/ws/2004/09/policy,http://www.w3.org/ns/
                   ws-policy)

                   Shortcut: puri


  Diagnostic/Help argument(s):
  ----------------------------
  debug - The flag(true/false) to indicate if the error trace is
          printed in case of an exception or if the detailed text is
          to be printed. The default value is false.

          Shortcut: d

  help - The flag(true/false) to indicate if help text is to be
         printed. The default value is false.

         Shortcut:h


 EXAMPLES
 --------
 
   Example 1: Calculate status of all features in a remote WSDL
   ------------------------------------------------------------
 
     java -jar policytool.jar process -w http://131.107.153.201/MTOM_Service_IndigoBP/Soap12MtomUtf8BP20.svc?wsdl

     
   Example 2: Calculate status of all features in a remote WSDL with all sub-assertions processed
   ----------------------------------------------------------------------------------------------
   
     java -jar policytool.jar process -w http://131.107.153.201/MTOM_Service_IndigoBP/Soap12MtomUtf8BP20.svc?wsdl -ar


   Example 3: Calculate status of all features in a policy file
   ------------------------------------------------------------
 
     java -jar policytool.jar process -w <location to standard policy file>


   Example 4: Calculate status of mtomp:OptimizedMimeSerialization in a local policy file
   --------------------------------------------------------------------------------------
 
     java  -jar policytool.jar process -w d:\work\policy.xml -assertionQName {http://schemas.xmlsoap.org/ws/2004/09/policy/optimizedmimeserialization}OptimizedMimeSerialization


   Example 5: Calculate status of features against a port
   --------------------------------------------------------------------------------------

     java  -jar policytool.jar process -w http://myhost/a.wsdl -lf logfile.xml -sqn {http://temp}EchoService -pn portName
  
 
 TROUBLE SHOOTING
 ----------------
 
 1.) ERROR - No route to host: connect (java.net.NoRouteToHostException)
 
     The wsdl could be outside fire-wall. If so, include http proxy
     information. e.g) java -Dhttp.proxyHost=www-proxy.us.oracle.com
     -Dhttp.proxyPort=80 -jar ......
